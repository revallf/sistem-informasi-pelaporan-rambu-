import React, { useState } from 'react';
import './Tindaklj.css';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import { Carousel, NavLink } from 'react-bootstrap';
import logo from '../assets/logonew.png';
import upload from '../assets/upload.png';          
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

function Tindaklj() {
  const [file, setFile] = useState(null);
  const [isChecked, setIsChecked] = useState(false);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!file || !isChecked) {
      alert('Harap upload file dan centang checkbox.');
      return;
    }
    // Submit form logic goes here
    console.log('File uploaded:', file);
  };

  return (
    <div className="app-container">
       {/* Navbar */}
       <nav className="navbar">
            <div className="container">
              <div className="navbar-logo"></div>
              <img src={logo} alt="Logo" className='logo' />
              <ul className="nav-links">
              <NavLink
                to="/"
                className={({ isActive}) => isActive ? 'nav-link active' : 'nav-link'}>
                <li onClick={() => navigate('/')} ><a href="#home">Beranda</a></li>
                    
              </NavLink>
              <NavLink
                to="/"
                className={({ isActive}) => isActive ? 'nav-link active' : 'nav-link'}>
                <li onClick={() => navigate('/Laporpage')}><a href="#about">Laporan</a></li>
              </NavLink>
              <NavLink
                to="/"
                className={({ isActive}) => isActive ? 'nav-link active' : 'nav-link'}>
                <li onClick={() => navigate('/StatusLaporPage')}><a href="#services">Status Pelaporan</a></li>
              </NavLink>
              
              </ul>
            </div> 
          </nav>

      {/* Form Section */}
      <div className="form-container">
        <h2>Tindak Lanjut</h2>
        <p>Upload Bukti (50% dari proses pemasangan rambu)</p>

        <form onSubmit={handleSubmit} className="upload-form">
          {/* File Upload Section */}
          <label className="file-upload">
            <input type="file" onChange={handleFileChange} />
            <span className="upload-text">
              <img src = {upload} alt="Upload" className="upload-icon" />
              <button className="upload-button">Select File</button>
            </span>
          </label>

          {/* Checkbox */}
          <div className="checkbox-container">
            <input
              type="checkbox"
              id="checkbox"
              checked={isChecked}
              onChange={() => setIsChecked(!isChecked)}
            />
            <label htmlFor="checkbox">
              Bukti yang diupload sesuai dengan keadaan sesungguhnya
            </label>
          </div>

          {/* Submit Button */}
          <button type="submit" className="submit-button">
            Laporkan
          </button>
        </form>
      </div>
    </div>
  );
}

export default Tindaklj;
