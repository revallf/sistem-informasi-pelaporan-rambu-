import React, { useState } from 'react';
import './Tindaklj.css';

function Tindaklj() {
  const [file, setFile] = useState(null);
  const [isChecked, setIsChecked] = useState(false);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!file || !isChecked) {
      alert('Harap upload file dan centang checkbox.');
      return;
    }
    // Submit form logic goes here
    console.log('File uploaded:', file);
  };

  return (
    <div className="app-container">
      {/* Navbar */}
      <nav className="navbar">
        <img src="/logo-bnpb.png" alt="BNPB Logo" className="logo" />
      </nav>

      {/* Form Section */}
      <div className="form-container">
        <h2>Tindak Lanjut</h2>
        <p>Upload Bukti (50% dari proses pemasangan rambu)</p>

        <form onSubmit={handleSubmit} className="upload-form">
          {/* File Upload Section */}
          <label className="file-upload">
            <input type="file" onChange={handleFileChange} />
            <span className="upload-text">
              <img src="/upload-icon.png" alt="Upload" className="upload-icon" />
              <button className="upload-button">Select File</button>
            </span>
          </label>

          {/* Checkbox */}
          <div className="checkbox-container">
            <input
              type="checkbox"
              id="checkbox"
              checked={isChecked}
              onChange={() => setIsChecked(!isChecked)}
            />
            <label htmlFor="checkbox">
              Bukti yang diupload sesuai dengan keadaan sesungguhnya
            </label>
          </div>

          {/* Submit Button */}
          <button type="submit" className="submit-button">
            Laporkan
          </button>
        </form>
      </div>
    </div>
  );
}

export default Tindaklj;
