import React from 'react';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import { Carousel, NavLink } from 'react-bootstrap';
import './InfoStatus.css';
import logo from '../assets/logonew.png';       
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

const InfoStatus = () => {
    const navigate = useNavigate()

    return(
        <div>
            {/* Navbar */}
            <nav className="navbar">
            <div className="container">
              <div className="navbar-logo"></div>
              <img src={logo} alt="Logo" className='logo' />
              <ul className="nav-links">
              <NavLink
                to="/"
                className={({ isActive}) => isActive ? 'nav-link active' : 'nav-link'}>
                <li onClick={() => navigate('/')} ><a href="#home">Beranda</a></li>
                    
              </NavLink>
              <NavLink
                to="/"
                className={({ isActive}) => isActive ? 'nav-link active' : 'nav-link'}>
                <li onClick={() => navigate('/Laporpage')}><a href="#about">Laporan</a></li>
              </NavLink>
              <NavLink
                to="/"
                className={({ isActive}) => isActive ? 'nav-link active' : 'nav-link'}>
                <li onClick={() => navigate('/StatusLaporPage')}><a href="#services">Status Pelaporan</a></li>
              </NavLink>
              
              </ul>
            </div> 
          </nav>

            <div className='laporan-container'>
                <div className='laporan-detail'></div>
                    <h3>NAMA</h3>
                    <p>Jajang</p>
                    
                    <h3>TGL</h3>
                    <p>24-05-2024</p>
                    
                    <h3>DESA</h3>
                    <p>Babakan</p>
                    
                    <h3>LOKASI</h3>
                    <p><a href="https://maps.app.goo.gl/msdksmkmdksmkmd">https://maps.app.goo.gl/msdksmkmdksmkmd</a></p>
                    
                    <h3>ISI LAPORAN</h3>
                    <p>Tidak ada Rambu pada tikungan tajam ini, sangat membahayakan.</p>

            </div>
                <div className='laporan-timeline'>
                    <div className='timeline-item'></div>
                    <div className='circle grey'></div>
                    <div className='timeline-content'>
                        <p>Membuat Laporan</p>
                        <a href='#bukti'></a>
                    </div>
                       

                </div>
                <div className='timeline-item'>
                <div className='circle blue'></div>
                    <div className='timeline-content'>
                        <p>Verifikasi Laporan</p>
                        <a href='#bukti'></a>
                    </div>
                        

                </div>
                <div className='timeline-item'>
                <div className='circle green'></div>
                    <div className='timeline-content'>
                        <p>Laporan Selesai</p>
                        <a href='#bukti'>Lihat Bukti</a>

                    </div>
                        
                </div>
                    
            <div>

            </div>
           
          
        </div>
    )

}
    




export default InfoStatus;