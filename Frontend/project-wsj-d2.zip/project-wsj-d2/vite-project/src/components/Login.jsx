import React, { useState } from 'react';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import {NavLink } from 'react-bootstrap';
import './Login.css'; // Buat CSS terpisah untuk styling
import logo from '../assets/logonew.png';       
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const navigate = useNavigate();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        // Lakukan sesuatu dengan username dan password (misal: API call)
        console.log('Username:', username);
        console.log('Password:', password);
        
    };

    return (
        <div>
            {/* Navbar */}
          <nav className="navbar">
            <div className="container">
              <div className="navbar-logo"></div>
              <img src={logo} alt="Logo" className='logo' />
              <ul className="nav-links">
              <NavLink
                to="/"
                className={({ isActive}) => isActive ? 'nav-link active' : 'nav-link'}>
                <li onClick={() => navigate('/')} ><a href="#home">Beranda</a></li>
                    
              </NavLink>
              <NavLink
                to="/"
                className={({ isActive}) => isActive ? 'nav-link active' : 'nav-link'}>
                <li onClick={() => navigate('/Laporpage')}><a href="#about">Laporan</a></li>
              </NavLink>
              <NavLink
                to="/"
                className={({ isActive}) => isActive ? 'nav-link active' : 'nav-link'}>
                <li onClick={() => navigate('/StatusLaporPage')}><a href="#services">Status Pelaporan</a></li>
              </NavLink>
              
              </ul>
            </div> 
          </nav>

            {/* Login Box */}
            <div className="login-box">
                <h1>LOGIN ADMIN</h1>
                <div className="divider"></div>
                <form onSubmit={handleSubmit}>
                    <div className="input-group">
                        <label htmlFor="username">Username</label>
                        <input
                            type="text"
                            id="username"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            placeholder="Masukkan username"
                        />
                    </div>
                    <div className="input-group">
                        <label htmlFor="password">Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Masukkan password"
                        />
                    </div>
                    <button type="submit" className="submit-btn">SUBMIT</button>
                </form>
            </div>
        </div>
    );
};

export default Login;