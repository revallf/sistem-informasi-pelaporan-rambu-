import React from 'react'
import App from '../App'
import Beranda from '../components/Beranda'

const Home = () => {
  return (
    <Beranda />
  )
}

export default Home