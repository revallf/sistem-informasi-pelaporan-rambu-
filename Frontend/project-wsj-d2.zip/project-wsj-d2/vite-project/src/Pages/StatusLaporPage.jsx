import React from 'react'
import StatusPelaporan from '../components/StatusPelaporan'


const StatusLaporPage = () => {
  return (
    <StatusPelaporan />
  )
}

export default StatusLaporPage