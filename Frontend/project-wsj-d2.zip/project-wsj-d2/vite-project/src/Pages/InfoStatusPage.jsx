import React from 'react'
import InfoStatus from '../components/InfoStatus'


const InfoStatusPage = () => {
  return (
    <InfoStatus/>
  )
}

export default InfoStatusPage