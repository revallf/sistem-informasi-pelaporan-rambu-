import React from 'react';
import Login from '../components/Login';

const Loginpage = () =>  {
    return (
        <div>
            <Login />
        </div>
    );
}

export default Loginpage;
