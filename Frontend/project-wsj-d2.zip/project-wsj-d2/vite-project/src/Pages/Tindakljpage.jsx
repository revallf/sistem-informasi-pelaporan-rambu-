import React from 'react';
import Tindaklj from '../components/Tindaklj';

const Tindakljpage = () =>  {
    return (
        <div>
            <Tindaklj />
        </div>
    );
}

export default Tindakljpage;
