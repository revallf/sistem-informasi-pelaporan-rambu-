import React from 'react'
import Laporan from '../components/Laporan'
const Laporpage = () => {
  return (
    <Laporan />
  )
}

export default Laporpage;